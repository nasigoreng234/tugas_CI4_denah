<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scaleRu=1.0">
    <title>Denah Perjalanan - SMKN 2 Karanganyar → Rumah Arrofi</title>
    <style>
        /* Reset & layout */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: #f0f2f5;
            color: #222;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            max-width: 1100px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }

        header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eaeaea;
        }

        h1 {
            font-size: 28px;
            color: #2c3e50;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .description {
            font-size: 16px;
            color: #555;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Container peta & kompas */
        .map-container {
            display: flex;
            gap: 30px;
            align-items: flex-start;
            flex-wrap: wrap;
            margin: 30px 0;
        }

        /* Kompas */
        .compass-container {
            flex: 0 0 200px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .compass {
            width: 150px;
            height: 150px;
            position: relative;
            border: 3px solid #2c3e50;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .compass:hover {
            transform: scale(1.05);
        }

        .compass .center {
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 16px;
            height: 16px;
            background: #e74c3c;
            border-radius: 50%;
            z-index: 2;
            position: absolute;
        }

        .compass .needle {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 2px;
            height: 60px;
            background: #e74c3c;
            transform-origin: center bottom;
            transform: translate(-50%, -100%) rotate(0deg);
            z-index: 1;
        }

        .compass .dir {
            position: absolute;
            font-weight: 800;
            font-size: 20px;
            color: #2c3e50;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }

        .compass .dir.n {
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .compass .dir.e {
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
        }

        .compass .dir.s {
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .compass .dir.w {
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
        }

        .compass-label {
            margin-top: 15px;
            font-size: 14px;
            color: #e74c3c;
            font-weight: 600;
            text-align: center;
        }

        /* Map Box */
        .map {
            flex: 1;
            min-width: 300px;
            height: 400px;
            border: 2px solid #2c3e50;
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        /* Base path styling */
        .path {
            position: absolute;
            background: #3498db;
            border-radius: 4px;
            z-index: 8;
        }

        /* Titik (marker) */
        .marker {
            position: absolute;
            width: 24px;
            height: 24px;
            border: 3px solid #fff;
            border-radius: 50%;
            background: #e74c3c;
            transform: translate(-50%, -50%);
            z-index: 12;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 800;
            color: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }

        .label {
            z-index: 13;
            background: rgba(255, 255, 255, 0.95);
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 180px;
            transition: transform 0.2s ease;
            position: absolute;
        }

        .label:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        /* Posisi marker & label */
        .start {
            left: 5%;
            top: 10%;
        }

        .start-label {
            left: 4%;
            top: 1%;
        }

        .belok1 {
            left: 15%;
            top: 10%;
        }

        .belok1-label {
            right: 0.5%;
            top: 52%;
        }

        .belok2 {
            left: 15%;
            top: 20%;
        }

        .belok3 {
            left: 24%;
            top: 20%;
        }

        .belok4 {
            left: 24%;
            top: 37%;
        }

        .belok5 {
            left: 52%;
            top: 38%;
        }

        .belok6 {
            left: 60%;
            top: 31%;
        }

        .belok7 {
            left: 78%;
            top: 35%;
        }

        .belok8 {
            left: 78%;
            top: 51%;
        }

        .belok2-label {
            right: 70%;
            top: 29%;
        }

        .belok3-label {
            right: 30%;
            top: 30%;
        }
        
        .belok4-label {
            right: 40%;
            top: 30%;
        }

        .belok5-label {
            right: 50%;
            top: 40%;
        }

        .belok6-label {
            right: 10%;
            top: 30%;
            
        }

        .belok7-label {
            right: 10%;
            top: 45%;
            transform: rotate(90deg);
        }

        .belok8-label {
            right: 25%;
            top: 30%;
        }

        .intan {
            left: 45%;
            top: 35%;
        }

        .intan-label {
            left: 40%;
            top: 24%;
        }

        .lampu {
            left: 35%;
            top: 35%;
        }

        .lampu-label {
            left: 32%;
            top: 36%;
        }

        .finish {
            left: 93%;
            top: 50%;
        }

        .finish-label {
            left: 40%;
            top: 7%;
        }

        /* Path segments */
        .path-1 {
            height: 8px;
            width: 10%;
            top: 10%;
            left: 5%;
        }

        .path-2 {
            width: 8px;
            height: 10%;
            top: 10%;
            left: 14%;
        }

        .path-3 {
            height: 8px;
            width: 10%;
            top: 19%;
            left: 14%;
        }

        .path-4 {
            width: 8px;
            height: 20%;
            top: 19%;
            left: 23%;
        }

        .path-5 {
            height: 8px;
            width: 30%;
            top: 37%;
            left: 23%;
            /* transform: rotate(15deg); */
        }

        .path-6 {
            height: 8px;
            width: 10%;
            top: 34%;
            left: 52%;
            transform: rotate(-17deg);
        }

        .path-7 {
            height: 8px;
            width: 8%;
            top: 33%;
            left: 61%;
            transform: rotate(15deg);
        }

        .path-8 {
            height: 8px;
            width: 10%;
            top: 35%;
            left: 68%;
        }

        .path-9 {
            height: 8px;
            width: 10%;
            top: 37%;
            left: 29%;
            transform: rotate(90deg);
        }

        .path-10 {
            height: 8px;
            width: 10%;
            top: 37%;
            left: 40%;
            transform: rotate(90deg);
        }

        .path-11 {
            height: 8px;
            width: 10%;
            top: 44%;
            left: 73%;
            transform: rotate(90deg);
        }

        .path-12 {
            height: 8px;
            width: 15%;
            top: 50%;
            left: 78%;
            /* transform: rotate(deg); */
        }

        /* Nama jalan */
        .roadname {
            position: absolute;
            font-size: 14px;
            color: #2c3e50;
            background: rgba(255, 255, 255, 0.9);
            padding: 5px 10px;
            border-radius: 20px;
            border: 1px solid #eaeaea;
            z-index: 9;
            font-weight: 600;
        }

        .road-1 {
            left: 35%;
            top: 75%;
        }

        .road-2 {
            left: 25%;
            top: 65%;
            transform: rotate(90deg);
        }

        .road-3 {
            left: 45%;
            top: 45%;
        }

        .road-4 {
            left: 55%;
            top: 35%;
            
        }

        .road-5 {
            left: 50%;
            top: 50%;
            transform: rotate(15deg);
        }

        /* Petunjuk / legend */
        .instructions {
            margin-top: 30px;
            background: #f9fafb;
            padding: 25px;
            border-radius: 10px;
            border-left: 5px solid #3498db;
        }

        .instructions h2 {
            font-size: 22px;
            margin-bottom: 15px;
            color: #2c3e50;
            display: flex;
            align-items: center;
        }

        .instructions h2:before {
            content: "📌";
            margin-right: 10px;
        }

        .instructions ol {
            padding-left: 20px;
            color: #444;
        }

        .instructions li {
            margin-bottom: 12px;
            padding-left: 5px;
        }

        .instructions li strong {
            color: #2c3e50;
        }

        .note {
            margin-top: 15px;
            padding: 15px;
            background: #fff4e6;
            border-radius: 8px;
            border-left: 4px solid #ffa94d;
            font-size: 14px;
        }

        /* Legenda */
        .legend {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 30px;
            justify-content: center;
            padding: 20px;
            background: #f9fafb;
            border-radius: 10px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .legend-color {
            border: 2px solid #fff;
            border-radius: 50%;
            margin-right: 10px;
            background: #e74c3c;
            width: 20px;
            height: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .legend-line {
            width: 40px;
            height: 6px;
            background: #3498db;
            margin-right: 10px;
            border-radius: 3px;
        }

        @media (max-width: 768px) {
            .map-container {
                flex-direction: column;
            }

            .compass-container {
                margin: 0 auto 30px;
            }

            .map {
                height: 400px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>Denah Perjalanan: SMKN 2 Karanganyar → Rumah Arrofi</h1>
            <p class="description">Denah dengan arah mata angin dan petunjuk perjalanan.</p>
        </header>

        <div class="map-container">
            <div class="compass-container">
                <div class="compass">
                    <div class="center"></div>
                    <div class="needle"></div>
                    <div class="dir n">N</div>
                    <div class="dir e">E</div>
                    <div class="dir s">S</div>
                    <div class="dir w">W</div>
                </div>
                <div class="compass-label">Arah Mata Angin</div>
            </div>

            <div class="map">
                <!-- Jalur perjalanan -->
                <div class="path path-1"></div>
                <div class="path path-2"></div>
                <div class="path path-3"></div>
                <div class="path path-4"></div>
                <div class="path path-5"></div>
                <div class="path path-6"></div>
                <div class="path path-7"></div>
                <div class="path path-8"></div>
                <div class="path path-9"></div>
                <div class="path path-10"></div>
                <div class="path path-11"></div>
                <div class="path path-12"></div>

                <!-- Titik-titik penting -->
                <div class="marker start" title="SMKN 2 Karanganyar">S</div>
                <div class="label start-label">START: SMKN 2 Kra</div> 

                <div class="marker belok1" title="Belok ke Utara">B1</div>
                <div class="label belok1-label">Finish</div>

                <div class="marker belok2" title="Belok ke Timur">B2</div>
                <div class="label belok2-label">Belok ke Timur</div>

                <div class="marker belok3" title="Belok ke Selatan">B3</div>
                <!-- <div class="label belok3-label">Belok ke Selatan</div> -->

                <div class="marker belok4" title="Belok ke Barat">B4</div>
                <!-- <div class="label belok4-label">Belok ke Barat</div> -->

                <div class="marker belok5" title="Belok ke Utara">B5</div>
                <!-- <div class="label belok5-label">Belok ke Utara</div> -->

                <div class="marker belok6" title="Belok ke Timur">B6</div>
                <!-- <div class="label belok6-label">Belok ke Timur</div> -->
                
                <div class="marker belok7" title="Belok ke Selatan">B7</div>
                <div class="label belok7-label">Belok ke Selatan</div>

                <div class="marker belok8" title="Belok ke Barat">B8</div>
                <div class="label belok8-label">Belok ke timur</div>

                <div class="marker intan" title="Intan Pari">L2</div>
                <div class="label intan-label">bangjo Karangpandan</div>

                <div class="marker lampu" title="Lampu Merah">L1</div>
                <div class="label lampu-label">Bangjo Mbejen</div>

                <div class="marker finish">F</div>

                

                <!-- Nama jalan -->
                <div class="roadname road-3">Jl. ke Timur</div>
                <div class="roadname road-4">Jl. Menuju Belokan Tawangmangu</div>
            </div>
        </div>

        <div class="instructions">
            <h2>Petunjuk Perjalanan :</h2>
            <ol>
                <li><strong>Mulai dari SMKN 2 Karanganyar</strong> (depan RSUD Karanganyar) → titik S pada denah</li>
                <li><strong>Berjalan ke timur</strong> menyusuri Jl. Yos Sudarso</li>
                <li><strong>Belok ke Selatan</strong> → titik B1 pada denah</li>
                <li><strong>Belok ke Timur</strong> → titik B2 pada denah</li>
                <li><strong>Belok ke Selatan</strong> → titik B3 pada denah</li>
                <li><strong>Menyusuri SMP 1 Karanganyar dan Belok ke Timur</strong> → titik B4 pada denah</li>
                <li><strong>Tiba di Lampu Merah/Simpang Bejen dan titik B5 </strong> → titik L1 pada denah</li>
                <li><strong>Menuju ke timur sampai dengan Lampu merah Karangpandan</strong> titik L2 dan lanjutkan perjalanan </li>
                <li><strong>Belok ke Timur dan Ambil arah lurus  </strong> → titik B6 pada denah</li>
                <li><strong>Belok ke Timur sampai ke B7</strong> → titik B7 pada denah</li>
                <li><strong>Belok ke Selatan sampai di B8</strong> → titik B8 pada denah</li>
                
                <li>Sampai di <strong>Finish/Rumah</strong> → titik F pada denah</li>
            </ol>
        </div>

        <div class="note">
            <strong>Catatan:</strong> Denah ini merupakan representasi sederhana. Untuk navigasi yang lebih akurat,
            gunakan aplikasi peta digital bersama dengan petunjuk ini.
        </div>

        <div class="legend">
            <div class="legend-item">
                <div class="legend-color"></div>
                <span>Posisi Penting</span>
            </div>
            <div class="legend-item">
                <div class="legend-line"></div>
                <span>Jalur Perjalanan</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #3498db;"></div>
                <span>Petunjuk Jalan</span>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const compassNeedle = document.querySelector('.compass .needle');

            if (window.DeviceOrientationEvent) {
                // Request permission (khusus iOS Safari >= 13)
                if (typeof DeviceOrientationEvent.requestPermission === 'function') {
                    DeviceOrientationEvent.requestPermission()
                        .then(permissionState => {
                            if (permissionState === 'granted') {
                                window.addEventListener("deviceorientationabsolute", updateCompass, true);
                            }
                        })
                        .catch(console.error);
                } else {
                    // Android / browser lain langsung pakai
                    window.addEventListener("deviceorientationabsolute", updateCompass, true);
                }
            } else {
                // fallback kalau device nggak support sensor
                compassNeedle.style.transform = 'translate(-50%, -100%) rotate(0deg)';
            }

            function updateCompass(event) {
                if (event.alpha !== null) {
                    // event.alpha = arah utara (0° = utara)
                    let angle = 360 - event.alpha;
                    compassNeedle.style.transform = `translate(-50%, -100%) rotate(${angle}deg)`;
                }
            }
        });
    </script>

</body>

</html>